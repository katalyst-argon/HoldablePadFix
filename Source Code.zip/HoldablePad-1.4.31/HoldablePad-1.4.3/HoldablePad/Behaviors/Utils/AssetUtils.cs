using System;
using System.IO;
using System.Threading.Tasks;
using UnityEngine;

namespace HoldablePad.Behaviors.Utils
{
    public static class AssetUtils
    {
        public static async Task<AssetBundle> LoadFromFile(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                Logger.LogError("Asset path is null or empty");
                return null;
            }

            if (!File.Exists(path))
            {
                Logger.LogError($"Asset file not found: {path}");
                return null;
            }

            try
            {
                var request = AssetBundle.LoadFromFileAsync(path);
                
                while (!request.isDone)
                    await Task.Yield();
                
                if (request.assetBundle == null)
                {
                    Logger.LogError($"Failed to load asset bundle from: {path}");
                    return null;
                }
                
                return request.assetBundle;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Exception loading asset bundle from file {path}: {ex}");
                return null;
            }
        }

        public static async Task<AssetBundle> LoadFromStream(string resourcePath)
        {
            if (string.IsNullOrEmpty(resourcePath))
            {
                Logger.LogError("Resource path is null or empty");
                return null;
            }

            try
            {
                var assembly = System.Reflection.Assembly.GetExecutingAssembly();
                using (var stream = assembly.GetManifestResourceStream(resourcePath))
                {
                    if (stream == null)
                    {
                        Logger.LogError($"Embedded resource not found: {resourcePath}");
                        return null;
                    }

                    byte[] data = new byte[stream.Length];
                    await stream.ReadAsync(data, 0, data.Length);
                    
                    var request = AssetBundle.LoadFromMemoryAsync(data);
                    
                    while (!request.isDone)
                        await Task.Yield();
                    
                    if (request.assetBundle == null)
                    {
                        Logger.LogError($"Failed to load asset bundle from stream: {resourcePath}");
                        return null;
                    }
                    
                    return request.assetBundle;
                }
            }
            catch (Exception ex)
            {
                Logger.LogError($"Exception loading asset bundle from stream {resourcePath}: {ex}");
                return null;
            }
        }

        public static async Task<T> LoadAsset<T>(AssetBundle bundle, string assetName) where T : UnityEngine.Object
        {
            if (bundle == null)
            {
                Logger.LogError($"Asset bundle is null when trying to load asset: {assetName}");
                return null;
            }

            if (string.IsNullOrEmpty(assetName))
            {
                Logger.LogError("Asset name is null or empty");
                return null;
            }

            try
            {
                var request = bundle.LoadAssetAsync<T>(assetName);
                
                while (!request.isDone)
                    await Task.Yield();
                
                var asset = request.asset as T;
                
                if (asset == null)
                {
                    Logger.LogError($"Failed to load asset '{assetName}' as type {typeof(T).Name} from bundle");
                    return null;
                }
                
                return asset;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Exception loading asset {assetName} from bundle: {ex}");
                return null;
            }
        }
    }
}
