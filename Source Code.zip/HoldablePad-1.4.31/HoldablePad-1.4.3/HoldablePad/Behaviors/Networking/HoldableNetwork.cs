﻿using ExitGames.Client.Photon;
using GorillaExtensions;
using HoldablePad.Behaviors.Utils;
using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace HoldablePad.Behaviors.Networking
{
    public class HoldableNetwork : MonoBehaviourPunCallbacks
    {

        public static HoldableNetwork Instance { get; private set; }
        public Main main;
        public Dictionary<Player, Client> Clients = new Dictionary<Player, Client>();

        public override void OnEnable()
        {
            base.OnEnable();
            PhotonNetwork.NetworkingClient.EventReceived += OnEvent;
        }

        public override void OnDisable()
        {
            base.OnDisable();
            PhotonNetwork.NetworkingClient.EventReceived -= OnEvent;
        }

        public override void OnPlayerEnteredRoom(Player newPlayer)
        {
            base.OnPlayerEnteredRoom(newPlayer);

            try
            {
                if (newPlayer == null || !PhotonNetwork.InRoom)
                    return;

                VRRig rig = GorillaGameManager.instance.FindPlayerVRRig(newPlayer);
                if (rig == null || rig.gameObject == null)
                    return;

                if (Clients.ContainsKey(newPlayer))
                    return;

                Client client = rig.gameObject.GetOrAddComponent<Client>();
                if (client != null)
                {
                    Clients.Add(newPlayer, client);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in OnPlayerEnteredRoom: {ex}");
            }
        }

        private void OnEvent(EventData photonEvent)
        {
            try
            {
                if (photonEvent == null || photonEvent.Code != 71)
                    return;

                if (!PhotonNetwork.InRoom)
                    return;

                object[] data = photonEvent.CustomData as object[];
                if (data == null || data.Length == 0)
                    return;

                Player eventSender = PhotonNetwork.CurrentRoom.GetPlayer(photonEvent.Sender);
                if (eventSender == null)
                    return;

                if (!Clients.TryGetValue(eventSender, out Client currentClient))
                {
                    VRRig senderRig = GorillaGameManager.instance.FindPlayerVRRig(eventSender);
                    if (senderRig != null && senderRig.gameObject != null)
                    {
                        currentClient = senderRig.gameObject.GetOrAddComponent<Client>();
                        if (currentClient != null)
                        {
                            Clients.Add(eventSender, currentClient);
                        }
                    }
                }

                if (currentClient == null)
                    return;

                if (data[0] is string basePath)
                {
                    if (main.InitalizedHoldablesDict.TryGetValue(basePath, out Holdables.Holdable holdableReference))
                    {
                        if (data.Length > 1 && data[1] is bool isLeft)
                        {
                            currentClient.Equip(holdableReference, isLeft);
                        }
                    }
                    else if (basePath == "None")
                    {
                        if (data.Length > 1 && data[1] is bool unequipLeft)
                        {
                            currentClient.Unequip(unequipLeft, data.Length > 2 && data[2] is bool unequipRight && unequipRight);
                        }
                    }
                }
                else
                {
                    currentClient.Unequip(false, false);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in OnEvent: {ex}");
            }
        }

        public override void OnLeftRoom()
        {
            base.OnLeftRoom();

            try
            {
                // FIX: isQuitting property was removed in newer versions
                // Just clear everything when leaving the room
                ScoreboardUtils.cachedLines.Clear();

                if (Clients != null && Clients.Values != null)
                {
                    Clients.Values.ToList().ForEach(x =>
                    {
                        if (x != null)
                            Destroy(x);
                    });
                }

                Clients.Clear();
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in OnLeftRoom: {ex}");
            }
        }

        public override void OnPlayerLeftRoom(Player otherPlayer)
        {
            base.OnPlayerLeftRoom(otherPlayer);

            try
            {
                if (otherPlayer == null)
                    return;

                if (Clients.TryGetValue(otherPlayer, out Client refClient))
                {
                    if (refClient != null)
                    {
                        Destroy(refClient);
                    }
                    Clients.Remove(otherPlayer);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in OnPlayerLeftRoom: {ex}");
            }
        }
    }
}