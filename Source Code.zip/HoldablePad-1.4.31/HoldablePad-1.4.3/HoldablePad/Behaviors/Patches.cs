using HarmonyLib;
using HoldablePad.Behaviors.Networking;
using HoldablePad.Behaviors.Utils;
using System;
using UnityEngine;

namespace HoldablePad.Behaviors
{
    [HarmonyPatch]
    public static class Patches
    {
        public static Color PlayerColour;

        [HarmonyPatch(typeof(GorillaTagger), "Start"), HarmonyPostfix]
        public static void InitPatch(GorillaTagger __instance)
        {
            try
            {
                if (__instance == null)
                {
                    Logger.LogError("GorillaTagger instance is null in InitPatch");
                    return;
                }

                var holdablePadParent = new GameObject("HoldablePadMain", typeof(Main));
                holdablePadParent.transform.parent = __instance.gameObject.transform;
                
                Logger.Log("HoldablePad initialized successfully");
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in InitPatch: {ex}");
                Logger.LogError($"Stack trace: {ex.StackTrace}");
            }
        }

        // Primary color patch - Update method name if needed based on your GT version
        [HarmonyPatch(typeof(GorillaTagger), "UpdateColor"), HarmonyPrefix]
        public static bool ColourPatch(float red, float green, float blue)
        {
            try
            {
                PlayerColour = new Color(red, green, blue);
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in ColourPatch: {ex}");
                return true;
            }
        }

        // Alternative color patch if UpdateColor method signature changed
        // Uncomment and use this if the above doesn't work:
        /*
        [HarmonyPatch(typeof(GorillaTagger))]
        [HarmonyPatch("UpdatePlayerColor")]
        [HarmonyPrefix]
        public static bool ColourPatchAlt(Color color)
        {
            try
            {
                PlayerColour = color;
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in ColourPatchAlt: {ex}");
                return true;
            }
        }
        */

        [HarmonyPatch(typeof(VRRig), "SetColor"), HarmonyPrefix]
        public static bool RigColourPatch(VRRig __instance, Color color)
        {
            try
            {
                if (__instance == null)
                {
                    Logger.LogWarning("VRRig instance is null in RigColourPatch");
                    return true;
                }

                if (__instance.gameObject == null)
                {
                    Logger.LogWarning("VRRig GameObject is null in RigColourPatch");
                    return true;
                }
                    
                if (__instance.gameObject.TryGetComponent(out Client client))
                {
                    client.currentColour = color;
                }
                
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in RigColourPatch: {ex}");
                return true;
            }
        }

        [HarmonyPatch(typeof(GorillaScoreBoard), "RedrawPlayerLines"), HarmonyPrefix, HarmonyWrapSafe]
        public static bool RedrawLinesPatch(GorillaScoreBoard __instance)
        {
            try
            {
                if (__instance == null)
                {
                    Logger.LogWarning("GorillaScoreBoard instance is null");
                    return true;
                }
                
                ScoreboardUtils.UpdateScoreboardHP(__instance);
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in RedrawLinesPatch: {ex}");
                return true;
            }
        }

        [HarmonyPatch(typeof(TransferrableBall), "OnCollisionEnter"), HarmonyPrefix, HarmonyWrapSafe]
        public static bool BallCollisionEnterPatch(Collision collision)
        {
            try
            {
                if (collision == null)
                    return true;
                    
                if (collision.rigidbody == null)
                    return true;
                    
                if (string.IsNullOrEmpty(collision.rigidbody.name))
                    return true;
                    
                if (collision.rigidbody.name.StartsWith("UsedBulletGameObject(Clone)"))
                {
                    return false; // Prevent collision
                }
                
                return true; // Allow collision
            }
            catch (Exception ex)
            {
                Logger.LogError($"Error in BallCollisionEnterPatch: {ex}");
                return true; // Default to allowing collision on error
            }
        }
    }
}
